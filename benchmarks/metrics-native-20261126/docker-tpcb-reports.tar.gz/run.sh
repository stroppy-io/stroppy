#!/usr/bin/env bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd)
E=$(dirname "$D")
: > "$D/results.jsonl"
position=0
for variant in base native-147 native-147 base; do
  position=$((position+1))
  database="measured_$position"
  docker exec stroppy-278-tpcb psql -U postgres -d postgres -v ON_ERROR_STOP=1 \
    -c "CREATE DATABASE $database TEMPLATE stroppy_template" > "$D/create-$position.txt"
  url="postgres://postgres:postgres@127.0.0.1:25435/$database?sslmode=disable"
  common=(run tpcb/tx -d pg -D "url=$url" -D pool.maxConns=8 --scale-factor 16 --tx-isolation read_committed --steps workload --executor constant-vus --vus 8 --no-save-report --report-format json --log-level warn)
  GOMAXPROCS=4 GOGC=100 GOMEMLIMIT=off "$E/stroppy-$variant" "${common[@]}" --duration 5s \
    > "$D/warm-$position-$variant.json" 2> "$D/warm-$position-$variant.stderr"
  docker exec stroppy-278-tpcb psql -U postgres -d "$database" -v ON_ERROR_STOP=1 \
    -c 'TRUNCATE pgbench_history' > "$D/reset-history-$position.txt"
  GOMAXPROCS=4 GOGC=100 GOMEMLIMIT=off "$E/stroppy-$variant" "${common[@]}" --duration 30s \
    > "$D/measure-$position-$variant.json" 2> "$D/measure-$position-$variant.stderr"
  jq -e '.status=="completed" and .errors.terminal_errors==0 and .errors.failed_iterations==0 and .errors.failed_queries==0' \
    "$D/measure-$position-$variant.json" > /dev/null
  jq -c --arg variant "$variant" --argjson position "$position" \
    '{variant:$variant,position:$position,tps:.metrics.tps.total,transactions:.metrics.successful_transactions_total.total,seconds:.measurement_seconds,errors:.errors}' \
    "$D/measure-$position-$variant.json" | tee -a "$D/results.jsonl"
  docker exec stroppy-278-tpcb psql -U postgres -d "$database" -At -v ON_ERROR_STOP=1 \
    -c 'SELECT count(*) FROM pgbench_history' > "$D/history-$position.txt"
  docker exec stroppy-278-tpcb psql -U postgres -d postgres -v ON_ERROR_STOP=1 \
    -c "DROP DATABASE $database" > "$D/drop-$position.txt"
done
