#!/usr/bin/env bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd)
E=$(dirname "$D")
cpus=${1:?client GOMAXPROCS required}
vus=${2:-8}
blocks=${3:-3}
: > "$D/results-cpu$cpus-vus$vus.jsonl"
position=0
for ((block=1;block<=blocks;block++)); do
  for variant in base native-147 native-147 base; do
    position=$((position+1))
    database="case_cpu${cpus}_vus${vus}_$position"
    stem="$D/cpu${cpus}-vus${vus}-block${block}-pos${position}-${variant}"
    docker exec stroppy-278-clientcpu psql -U postgres -d postgres -v ON_ERROR_STOP=1 \
      -c "CREATE DATABASE $database TEMPLATE stroppy_template" > "$stem-create.txt"
    url="postgres://postgres:postgres@127.0.0.1:25435/$database?sslmode=disable"
    common=(run tpcb/tx -d pg -D "url=$url" -D "pool.maxConns=$vus" --scale-factor 16 --tx-isolation read_committed --steps workload --executor constant-vus --vus "$vus" --no-save-report --report-format json --log-level warn)
    GOMAXPROCS=$cpus GOGC=100 GOMEMLIMIT=off "$E/stroppy-$variant" "${common[@]}" --duration 5s \
      > "$stem-warm.json" 2> "$stem-warm.stderr"
    jq -e '.status=="completed" and .errors.terminal_errors==0 and .errors.failed_iterations==0 and .errors.failed_queries==0' "$stem-warm.json" > /dev/null
    docker exec stroppy-278-clientcpu psql -U postgres -d "$database" -v ON_ERROR_STOP=1 \
      -c 'TRUNCATE pgbench_history' > "$stem-reset.txt"
    before=$(docker exec stroppy-278-clientcpu grep '^usage_usec ' /sys/fs/cgroup/cpu.stat | cut -d' ' -f2)
    /usr/bin/time -lp -o "$stem-time.txt" env GOMAXPROCS=$cpus GOGC=100 GOMEMLIMIT=off \
      "$E/stroppy-$variant" "${common[@]}" --duration 20s > "$stem.json" 2> "$stem.stderr"
    after=$(docker exec stroppy-278-clientcpu grep '^usage_usec ' /sys/fs/cgroup/cpu.stat | cut -d' ' -f2)
    jq -e '.status=="completed" and .errors.terminal_errors==0 and .errors.failed_iterations==0 and .errors.failed_queries==0 and .errors.retry_attempts==0' "$stem.json" > /dev/null
    history=$(docker exec stroppy-278-clientcpu psql -U postgres -d "$database" -At -v ON_ERROR_STOP=1 -c 'SELECT count(*) FROM pgbench_history')
    user=$(grep '^user ' "$stem-time.txt" | tr -s ' ' | cut -d' ' -f2)
    system=$(grep '^sys ' "$stem-time.txt" | tr -s ' ' | cut -d' ' -f2)
    real=$(grep '^real ' "$stem-time.txt" | tr -s ' ' | cut -d' ' -f2)
    jq -ce --arg variant "$variant" --argjson cpus "$cpus" --argjson vus "$vus" --argjson block "$block" \
      --argjson position "$position" --argjson history "$history" --argjson user "$user" --argjson system "$system" \
      --argjson real "$real" --argjson dbusec "$((after-before))" \
      '{variant:$variant,cpus:$cpus,vus:$vus,block:$block,position:$position,tps:.metrics.tps.total,
        transactions:.metrics.successful_transactions_total.total,history:$history,seconds:.measurement_seconds,
        client_cpu_seconds:($user+$system),client_cpu_percent:(100*($user+$system)/$real),
        db_cpu_seconds:($dbusec/1000000),db_cpu_percent:(100*$dbusec/1000000/$real),errors:.errors} |
        if .transactions==.history then . else error("history mismatch") end' "$stem.json" \
      | tee -a "$D/results-cpu$cpus-vus$vus.jsonl"
    docker exec stroppy-278-clientcpu psql -U postgres -d postgres -v ON_ERROR_STOP=1 \
      -c "DROP DATABASE $database" > "$stem-drop.txt"
  done
done
