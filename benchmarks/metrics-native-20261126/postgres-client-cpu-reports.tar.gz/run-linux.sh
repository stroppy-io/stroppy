#!/usr/bin/env bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd)
E=$(dirname "$D")
cpus=${1:?client CPU quota required}
vus=${2:-8}
blocks=${3:-3}
: > "$D/linux-results-cpu$cpus-vus$vus.jsonl"
position=0
for ((block=1;block<=blocks;block++)); do
  for variant in base native-147 native-147 base; do
    position=$((position+1))
    database="linux_cpu${cpus}_vus${vus}_$position"
    client="stroppy-278-linux-c${cpus}-v${vus}-p${position}"
    stem="$D/linux-cpu${cpus}-vus${vus}-block${block}-pos${position}-${variant}"
    docker exec stroppy-278-clientcpu psql -U postgres -d postgres -v ON_ERROR_STOP=1 \
      -c "CREATE DATABASE $database TEMPLATE stroppy_template" > "$stem-create.txt"
    docker create --name "$client" --cpus "$cpus" --memory 768m --network container:stroppy-278-clientcpu \
      -v "$E:/evidence:ro" -v "$D:/out" -e GOMAXPROCS="$cpus" -e GOGC=100 -e GOMEMLIMIT=off \
      --entrypoint /bin/sh postgres:17 -c '
      set -eu
      b=$1; db=$2; stem=$3; vus=$4
      common=""
      /evidence/$b run tpcb/tx -d pg -D "url=postgres://postgres:postgres@127.0.0.1:5432/$db?sslmode=disable" \
        -D "pool.maxConns=$vus" --scale-factor 16 --tx-isolation read_committed --steps workload \
        --executor constant-vus --vus "$vus" --duration 5s --report-format json --no-save-report --log-level warn \
        > "/out/$stem-warm.json" 2> "/out/$stem-warm.stderr"
      PGPASSWORD=postgres psql -h 127.0.0.1 -U postgres -d "$db" -v ON_ERROR_STOP=1 -c "TRUNCATE pgbench_history" > "/out/$stem-reset.txt"
      grep "^usage_usec " /sys/fs/cgroup/cpu.stat > "/out/$stem-client-before.txt"
      /evidence/$b run tpcb/tx -d pg -D "url=postgres://postgres:postgres@127.0.0.1:5432/$db?sslmode=disable" \
        -D "pool.maxConns=$vus" --scale-factor 16 --tx-isolation read_committed --steps workload \
        --executor constant-vus --vus "$vus" --duration 20s --report-format json --no-save-report --log-level warn \
        > "/out/$stem.json" 2> "/out/$stem.stderr"
      grep "^usage_usec " /sys/fs/cgroup/cpu.stat > "/out/$stem-client-after.txt"
      ' sh "stroppy-$variant-linux" "$database" "$(basename "$stem")" "$vus" > "$stem-client-id"
    before=$(docker exec stroppy-278-clientcpu grep '^usage_usec ' /sys/fs/cgroup/cpu.stat | cut -d' ' -f2)
    docker start -a "$client" > "$stem-container.log" 2>&1
    after=$(docker exec stroppy-278-clientcpu grep '^usage_usec ' /sys/fs/cgroup/cpu.stat | cut -d' ' -f2)
    exitcode=$(docker inspect "$client" --format '{{.State.ExitCode}}')
    [[ $exitcode == 0 ]] || { printf 'client exit %s\n' "$exitcode"; exit 1; }
    jq -e '.status=="completed" and .errors.terminal_errors==0 and .errors.failed_iterations==0 and .errors.failed_queries==0 and .errors.retry_attempts==0' "$stem.json" > /dev/null
    history=$(docker exec stroppy-278-clientcpu psql -U postgres -d "$database" -At -v ON_ERROR_STOP=1 -c 'SELECT count(*) FROM pgbench_history')
    c_before=$(cut -d' ' -f2 "$stem-client-before.txt")
    c_after=$(cut -d' ' -f2 "$stem-client-after.txt")
    jq -ce --arg variant "$variant" --argjson cpus "$cpus" --argjson vus "$vus" --argjson block "$block" \
      --argjson position "$position" --argjson history "$history" --argjson clientusec "$((c_after-c_before))" \
      --argjson dbusec "$((after-before))" \
      '{variant:$variant,cpus:$cpus,vus:$vus,block:$block,position:$position,tps:.metrics.tps.total,
        transactions:.metrics.successful_transactions_total.total,history:$history,seconds:.measurement_seconds,
        client_cpu_seconds:($clientusec/1000000),client_cpu_percent:(100*$clientusec/1000000/.measurement_seconds),
        db_cpu_seconds_including_warmup:($dbusec/1000000),errors:.errors} |
        if .transactions==.history then . else error("history mismatch") end' "$stem.json" \
      | tee -a "$D/linux-results-cpu$cpus-vus$vus.jsonl"
    docker rm "$client" > "$stem-client-removed.txt"
    docker exec stroppy-278-clientcpu psql -U postgres -d postgres -v ON_ERROR_STOP=1 \
      -c "DROP DATABASE $database" > "$stem-drop.txt"
  done
done
